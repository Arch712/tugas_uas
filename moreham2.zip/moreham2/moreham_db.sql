CREATE DATABASE IF NOT EXISTS moreham_db;
USE moreham_db;

CREATE TABLE film (
    id INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(100) NOT NULL,
    deskripsi TEXT,
    durasi INT,
    genre VARCHAR(50),
    poster VARCHAR(255)
);

CREATE TABLE jadwal_film (
    id INT AUTO_INCREMENT PRIMARY KEY,
    film_id INT NOT NULL,
    tanggal_tayang DATE NOT NULL,
    jam TIME NOT NULL,
    studio VARCHAR(20),
    FOREIGN KEY (film_id) REFERENCES film(id) ON DELETE CASCADE
);

CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

INSERT INTO admin (username, password) VALUES ('admin', MD5('123'));
