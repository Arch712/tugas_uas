<form method="post" action="<?= site_url('tiket/hasil') ?>">
    <input type="text" name="keyword" placeholder="Cari film...">
    <button type="submit">Cari</button>
</form>
