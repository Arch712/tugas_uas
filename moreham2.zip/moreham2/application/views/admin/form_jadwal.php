<form method="post">
    Judul: <input type="text" name="judul"><br>
    Tanggal Tayang: <input type="date" name="tanggal_tayang"><br>
    Jam: <input type="time" name="jam"><br>
    Studio: <input type="text" name="studio"><br>
    <button type="submit">Simpan</button>
</form>
